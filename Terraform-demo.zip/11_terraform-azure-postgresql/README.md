# Terraform Azure PostgreSQL

Deploy an Azure Database for PostgreSQL using Terraform

Blog post --> https://medium.com/@gmusumeci/how-to-deploy-an-azure-database-for-postgresql-using-terraform-a35a0e0ded68
